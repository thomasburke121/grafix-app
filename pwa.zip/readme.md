# The Love2Dev PWA Starter Kit

## Assets

    - index.html
    - manifest.json
    - sw.js
    - js/a2hs.js
    - js/a2hs.min.js
    - css/a2hs.css
    - meta/[platforms]/[icons]
    - a2hs/[platform guidance images]